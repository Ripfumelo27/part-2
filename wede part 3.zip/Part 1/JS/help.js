document.querySelector('.navigation a:first-child').addEventListener('click', function(e) {
    if (window.innerWidth <= 480) {
        e.preventDefault();
        this.parentElement.classList.toggle('responsive');
    }
});
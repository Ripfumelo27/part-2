

document.addEventListener('DOMContentLoaded', function() {
    
    const loginPopupBtn = document.querySelector('.btnLogin-popup');
    const accountForm = document.getElementById('accountform');
    const signupForm = accountForm.querySelector('form');
    const loginLink = accountForm.querySelector('a[href="#"]');
    
    
    let isLoginForm = false;
    
   
    initForm();
    
    
    if (loginPopupBtn) {
        loginPopupBtn.addEventListener('click', function() {
            
            accountForm.scrollIntoView({ behavior: 'smooth' });
            
            
            if (!isLoginForm) {
                toggleForms();
            }
        });
    }
    
    
    if (loginLink) {
        loginLink.addEventListener('click', function(e) {
            e.preventDefault();
            toggleForms();
        });
    }
    
    
    if (signupForm) {
        signupForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            if (validateForm()) {
                
                processForm();
            }
        });
    }
    
    function initForm() {
        
        const inputs = signupForm.querySelectorAll('input');
        inputs[0].name = 'username';
        inputs[1].name = 'email';
        inputs[2].name = 'password';
        
        
        addPasswordConfirmField();
    }
    
    function addPasswordConfirmField() {
        const passwordGroup = signupForm.querySelectorAll('.input-group')[2];
        const confirmGroup = passwordGroup.cloneNode(true);
        confirmGroup.querySelector('input').placeholder = 'Confirm Password';
        confirmGroup.querySelector('input').name = 'confirmPassword';
        passwordGroup.parentNode.insertBefore(confirmGroup, passwordGroup.nextSibling);
        
        
        const submitBtn = signupForm.querySelector('button');
        submitBtn.textContent = 'Sign Up';
    }
    
    function toggleForms() {
        isLoginForm = !isLoginForm;
        
        const formTitle = signupForm.parentElement.querySelector('h2');
        const submitBtn = signupForm.querySelector('button');
        const toggleLink = signupForm.parentElement.querySelector('p');
        
        if (isLoginForm) {
            
            formTitle.textContent = 'Login';
            submitBtn.textContent = 'Login';
            toggleLink.innerHTML = 'Don\'t have an account? <a href="#">Sign Up</a>';
            
            
            const usernameGroup = signupForm.querySelectorAll('.input-group')[0];
            const confirmGroup = signupForm.querySelectorAll('.input-group')[3];
            usernameGroup.style.display = 'none';
            confirmGroup.style.display = 'none';
        } else {
            
            formTitle.textContent = 'Sign Up';
            submitBtn.textContent = 'Sign Up';
            toggleLink.innerHTML = 'Already have an account? <a href="#">Login</a>';
            
            
            const inputGroups = signupForm.querySelectorAll('.input-group');
            inputGroups.forEach(group => {
                group.style.display = 'flex';
            });
        }
    }
    
    function validateForm() {
        let isValid = true;
        const inputs = signupForm.querySelectorAll('input');
        
        
        clearErrors();
        
        if (isLoginForm) {
           
            const email = inputs[1].value.trim();
            const password = inputs[2].value.trim();
            
            if (email === '') {
                showError(inputs[1], 'Email is required');
                isValid = false;
            } else if (!validateEmail(email)) {
                showError(inputs[1], 'Please enter a valid email');
                isValid = false;
            }
            
            if (password === '') {
                showError(inputs[2], 'Password is required');
                isValid = false;
            }
        } else {
            
            const username = inputs[0].value.trim();
            const email = inputs[1].value.trim();
            const password = inputs[2].value.trim();
            const confirmPassword = inputs[3].value.trim();
            
            if (username === '') {
                showError(inputs[0], 'Username is required');
                isValid = false;
            } else if (username.length < 4) {
                showError(inputs[0], 'Username must be at least 4 characters');
                isValid = false;
            }
            
            if (email === '') {
                showError(inputs[1], 'Email is required');
                isValid = false;
            } else if (!validateEmail(email)) {
                showError(inputs[1], 'Please enter a valid email');
                isValid = false;
            }
            
            if (password === '') {
                showError(inputs[2], 'Password is required');
                isValid = false;
            } else if (password.length < 8) {
                showError(inputs[2], 'Password must be at least 8 characters');
                isValid = false;
            }
            
            if (confirmPassword === '') {
                showError(inputs[3], 'Please confirm your password');
                isValid = false;
            } else if (password !== confirmPassword) {
                showError(inputs[3], 'Passwords do not match');
                isValid = false;
            }
        }
        
        return isValid;
    }
    
    function showError(input, message) {
        const errorSpan = document.createElement('span');
        errorSpan.className = 'error-message';
        errorSpan.textContent = message;
        errorSpan.style.color = 'red';
        errorSpan.style.fontSize = '0.8em';
        errorSpan.style.display = 'block';
        errorSpan.style.marginTop = '5px';
        
        const inputGroup = input.parentElement;
        inputGroup.appendChild(errorSpan);
        inputGroup.style.border = '1px solid red';
    }
    
    function clearErrors() {
        const errorMessages = signupForm.querySelectorAll('.error-message');
        errorMessages.forEach(msg => msg.remove());
        
        const inputGroups = signupForm.querySelectorAll('.input-group');
        inputGroups.forEach(group => {
            group.style.border = 'none';
        });
    }
    
    function validateEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }
    
    function processForm() {
        const formData = {};
        const inputs = signupForm.querySelectorAll('input');
        
        if (isLoginForm) {
        
            formData.email = inputs[1].value.trim();
            formData.password = inputs[2].value.trim();
            console.log('Login data:', formData);
            
    
            
           
            alert('Login successful! Redirecting...');
           
        } else {
            
            formData.username = inputs[0].value.trim();
            formData.email = inputs[1].value.trim();
            formData.password = inputs[2].value.trim();
            console.log('Signup data:', formData);
            
            
            
            
            alert('Account created successfully! Please login.');
            toggleForms();
        }
        
        
        inputs.forEach(input => input.value = '');
    }



});



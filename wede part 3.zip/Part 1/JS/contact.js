

document.addEventListener('DOMContentLoaded', function() {
    
    
   
    const contactItems = document.querySelectorAll('ul ol');
    contactItems.forEach(item => {
        item.addEventListener('mouseover', function() {
            this.style.color = '#007bff';
            this.style.transition = 'color 0.3s ease';
        });
        
        item.addEventListener('mouseout', function() {
            this.style.color = '';
        });
    });

    
    const main = document.querySelector('main');
    const contactFormHTML = `
        <div class="contact-form-container">
            <h2>Send Us a Message</h2>
            <form id="contactForm" class="contact-form">
                <div class="form-group">
                    <label for="name">Your Name:</label>
                    <input type="text" id="name" name="name" required>
                    <div class="error-message" id="nameError"></div>
                </div>
                
                <div class="form-group">
                    <label for="email">Your Email:</label>
                    <input type="email" id="email" name="email" required>
                    <div class="error-message" id="emailError"></div>
                </div>
                
                <div class="form-group">
                    <label for="subject">Subject:</label>
                    <input type="text" id="subject" name="subject" required>
                    <div class="error-message" id="subjectError"></div>
                </div>
                
                <div class="form-group">
                    <label for="message">Message:</label>
                    <textarea id="message" name="message" rows="5" required></textarea>
                    <div class="error-message" id="messageError"></div>
                </div>
                
                <button type="submit" class="btn">Send Message</button>
            </form>
            <div id="formSuccess" class="success-message"></div>
        </div>
    `;
    
    main.insertAdjacentHTML('beforeend', contactFormHTML);

   
    const contactForm = document.getElementById('contactForm');
    const successMessage = document.getElementById('formSuccess');
    
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
           
            clearErrorMessages();
            successMessage.textContent = '';
            successMessage.style.display = 'none';
            
            // Validate form
            if (validateForm()) {
                
                processForm();
            }
        });
    }

    function validateForm() {
        let isValid = true;
        
        // Name validation
        const name = document.getElementById('name').value.trim();
        if (name === '') {
            showError('nameError', 'Name is required');
            isValid = false;
        }
        
        // Email validation
        const email = document.getElementById('email').value.trim();
        if (email === '') {
            showError('emailError', 'Email is required');
            isValid = false;
        } else if (!isValidEmail(email)) {
            showError('emailError', 'Please enter a valid email address');
            isValid = false;
        }
        
        // Subject validation
        const subject = document.getElementById('subject').value.trim();
        if (subject === '') {
            showError('subjectError', 'Subject is required');
            isValid = false;
        }
        
        // Message validation
        const message = document.getElementById('message').value.trim();
        if (message === '') {
            showError('messageError', 'Message is required');
            isValid = false;
        } else if (message.length < 10) {
            showError('messageError', 'Message should be at least 10 characters');
            isValid = false;
        }
        
        return isValid;
    }

    function showError(elementId, message) {
        const errorElement = document.getElementById(elementId);
        errorElement.textContent = message;
        errorElement.style.color = 'red';
        errorElement.style.fontSize = '0.8em';
        errorElement.style.marginTop = '5px';
    }

    function clearErrorMessages() {
        const errorMessages = document.querySelectorAll('.error-message');
        errorMessages.forEach(msg => {
            msg.textContent = '';
        });
    }

    function isValidEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }

    function processForm() {
        const formData = {
            name: document.getElementById('name').value.trim(),
            email: document.getElementById('email').value.trim(),
            subject: document.getElementById('subject').value.trim(),
            message: document.getElementById('message').value.trim()
        };

        // In a real application, you would send this to a server
        console.log('Form data to be submitted:', formData);
        
        // For demo purposes, we'll just show a success message
        successMessage.textContent = 'Thank you for your message! We will contact you soon.';
        successMessage.style.display = 'block';
        successMessage.style.color = 'green';
        successMessage.style.marginTop = '15px';
        
        // Reset the form
        contactForm.reset();
        
        
        successMessage.scrollIntoView({ behavior: 'smooth' });
    }

    // 4. Enhance the WhatsApp link
    const whatsappLink = document.querySelector('a[href^="https://wa.me"]');
    if (whatsappLink) {
        whatsappLink.addEventListener('click', function(e) {
            e.preventDefault();
            // You could add tracking or analytics here
            window.open(this.href, '_blank');
        });
    }

    // 5. Make the map interactive
    const iframe = document.querySelector('iframe');
    if (iframe) {
        iframe.addEventListener('mouseover', function() {
            this.style.boxShadow = '0 0 15px rgba(0, 0, 0, 0.2)';
            this.style.transition = 'box-shadow 0.3s ease';
        });
        
        iframe.addEventListener('mouseout', function() {
            this.style.boxShadow = 'none';
        });
    }

    document.querySelector('.navigation a:first-child').addEventListener('click', function(e) {
    if (window.innerWidth <= 480) {
        e.preventDefault();
        this.parentElement.classList.toggle('responsive');
    }
});
});

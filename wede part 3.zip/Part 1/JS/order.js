// order.js

document.addEventListener('DOMContentLoaded', function() {
    // Form elements
    const orderForm = document.querySelector('main');
    const submitBtn = orderForm.querySelector('button[type="submit"]');
    const sameAsBillingCheckboxes = orderForm.querySelectorAll('input[type="checkbox"]');
    
    // Initialize form
    initForm();
    
    // Event listeners
    if (submitBtn) {
        submitBtn.addEventListener('click', function(e) {
            e.preventDefault();
            if (validateForm()) {
                processOrder();
            }
        });
    }
    
    // Toggle shipping address visibility
    sameAsBillingCheckboxes.forEach(checkbox => {
        checkbox.addEventListener('change', function() {
            toggleShippingAddress(this);
        });
    });
    
    // Format credit card number
    const ccInput = orderForm.querySelector('input[placeholder="1234 1234 1234 1234"]');
    if (ccInput) {
        ccInput.addEventListener('input', formatCreditCardNumber);
    }
    
    // Format expiration date
    const expInput = orderForm.querySelector('input[placeholder="MM/YY"]');
    if (expInput) {
        expInput.addEventListener('input', formatExpirationDate);
    }

    function initForm() {
        // Add IDs to all inputs for easier selection
        const inputs = orderForm.querySelectorAll('input');
        const labels = orderForm.querySelectorAll('label[for]');
        
        labels.forEach((label, index) => {
            const inputId = label.getAttribute('for').replace(/\s+/g, '-').toLowerCase();
            if (inputs[index]) {
                inputs[index].id = inputId;
                inputs[index].name = inputId;
                
                // Add classes for styling
                inputs[index].classList.add('form-input');
                
                // Set required attribute based on whether the field has 'required'
                if (inputs[index].hasAttribute('required')) {
                    label.innerHTML += ' <span class="required">*</span>';
                }
            }
        });
        
        // Style the submit button
        submitBtn.classList.add('submit-btn');
    }
    
    function toggleShippingAddress(checkbox) {
        const shippingFields = [
            'street-address',
            'province',
            'city',
            'postal-code'
        ];
        
        // Uncheck the other checkbox
        sameAsBillingCheckboxes.forEach(cb => {
            if (cb !== checkbox) {
                cb.checked = false;
            }
        });
        
        const isSameAddress = document.getElementById('yes').checked;
        
        shippingFields.forEach(fieldId => {
            const field = document.getElementById(fieldId);
            if (field) {
                field.disabled = isSameAddress;
                field.closest('label').style.opacity = isSameAddress ? 0.5 : 1;
            }
        });
    }
    
    function formatCreditCardNumber(e) {
        // Remove all non-digit characters
        let value = e.target.value.replace(/\D/g, '');
        
        // Add space after every 4 digits
        value = value.replace(/(\d{4})(?=\d)/g, '$1 ');
        
        // Limit to 16 digits
        if (value.length > 19) {
            value = value.substring(0, 19);
        }
        
        e.target.value = value;
    }
    
    function formatExpirationDate(e) {
        let value = e.target.value.replace(/\D/g, '');
        
        // Add slash after 2 digits
        if (value.length > 2) {
            value = value.substring(0, 2) + '/' + value.substring(2, 4);
        }
        
        // Limit to 5 characters (MM/YY)
        if (value.length > 5) {
            value = value.substring(0, 5);
        }
        
        e.target.value = value;
    }
    
    function validateForm() {
        let isValid = true;
        
        // Clear previous errors
        clearErrors();
        
        // Validate required fields
        const requiredFields = orderForm.querySelectorAll('input[required]');
        requiredFields.forEach(field => {
            if (!field.value.trim()) {
                showError(field, 'This field is required');
                isValid = false;
            }
        });
        
        // Validate full name
        const fullName = document.getElementById('full-names');
        if (fullName && fullName.value.trim().length < 3) {
            showError(fullName, 'Please enter your full name');
            isValid = false;
        }
        
        // Validate contact number
        const contactNumber = document.getElementById('contact-number');
        if (contactNumber) {
            const phoneRegex = /^[0-9]{10,15}$/;
            const digitsOnly = contactNumber.value.replace(/\D/g, '');
            if (!phoneRegex.test(digitsOnly)) {
                showError(contactNumber, 'Please enter a valid phone number');
                isValid = false;
            }
        }
        
        // Validate credit card
        const ccNumber = document.getElementById('credit-card-number');
        if (ccNumber) {
            const digitsOnly = ccNumber.value.replace(/\D/g, '');
            if (digitsOnly.length !== 16) {
                showError(ccNumber, 'Please enter a valid 16-digit card number');
                isValid = false;
            }
        }
        
        // Validate expiration date
        const expDate = document.getElementById('card-expiration');
        if (expDate) {
            const [month, year] = expDate.value.split('/');
            if (!month || !year || month.length !== 2 || year.length !== 2) {
                showError(expDate, 'Please enter a valid MM/YY date');
                isValid = false;
            } else {
                const currentDate = new Date();
                const currentYear = currentDate.getFullYear() % 100;
                const currentMonth = currentDate.getMonth() + 1;
                
                if (parseInt(year) < currentYear || 
                    (parseInt(year) === currentYear && parseInt(month) < currentMonth)) {
                    showError(expDate, 'This card has expired');
                    isValid = false;
                }
            }
        }
        
        // Validate security code
        const securityCode = document.getElementById('security-code');
        if (securityCode && securityCode.value.replace(/\D/g, '').length !== 3) {
            showError(securityCode, 'Please enter a valid 3-digit CVC');
            isValid = false;
        }
        
        return isValid;
    }
    
    function showError(input, message) {
        const errorSpan = document.createElement('span');
        errorSpan.className = 'error-message';
        errorSpan.textContent = message;
        errorSpan.style.color = 'red';
        errorSpan.style.fontSize = '0.8em';
        errorSpan.style.display = 'block';
        
        // Insert after the input
        input.parentNode.insertBefore(errorSpan, input.nextSibling);
        input.style.borderColor = 'red';
    }
    
    function clearErrors() {
        const errorMessages = orderForm.querySelectorAll('.error-message');
        errorMessages.forEach(msg => msg.remove());
        
        const inputs = orderForm.querySelectorAll('input');
        inputs.forEach(input => {
            input.style.borderColor = '';
        });
    }
    
    function processOrder() {
        // Collect form data
        const formData = {
            fullName: document.getElementById('full-names').value.trim(),
            contactNumber: document.getElementById('contact-number').value.trim(),
            billingAddress: document.getElementById('billing-adress').value.trim(),
            streetAddress: document.getElementById('street-address').value.trim(),
            province: document.getElementById('province').value.trim(),
            city: document.getElementById('city').value.trim(),
            postalCode: document.getElementById('postal-code').value.trim(),
            sameAsBilling: document.getElementById('yes').checked,
            paymentMethod: 'credit', // Would be dynamic in a real app
            creditCardNumber: document.getElementById('credit-card-number').value.trim(),
            expirationDate: document.getElementById('card-expiration').value.trim(),
            securityCode: document.getElementById('security-code').value.trim()
        };
        
        // In a real app, you would send this to your server
        console.log('Order data:', formData);
        
        // Show success message
        alert('Order submitted successfully! Thank you for your purchase.');
        
        // Reset form
        orderForm.querySelector('form').reset();
        
        // In a real app, you might redirect to a confirmation page
        // window.location.href = 'confirmation.html';
    }

    document.querySelector('.navigation a:first-child').addEventListener('click', function(e) {
    if (window.innerWidth <= 480) {
        e.preventDefault();
        this.parentElement.classList.toggle('responsive');
    }
});
});

document.addEventListener('DOMContentLoaded', function() {
    
    const navToggle = document.querySelector('.navigation a:first-child');
    
    if (navToggle) {
        navToggle.addEventListener('click', function(e) {
            if (window.innerWidth <= 768) {
                e.preventDefault();
                document.querySelector('.navigation').classList.toggle('responsive');
            }
        });
    }

    
    const navLinks = document.querySelectorAll('.navigation a:not(:first-child)');
    navLinks.forEach(link => {
        link.addEventListener('click', function() {
            if (window.innerWidth <= 768) {
                document.querySelector('.navigation').classList.remove('responsive');
            }
        });
    });

    
    const quantityInputs = document.querySelectorAll('input[type="number"]');
    quantityInputs.forEach(input => {
        input.addEventListener('change', function() {
            updateCartPreview();
        });
    });

    
    function updateCartPreview() {
        let totalItems = 0;
        quantityInputs.forEach(input => {
            totalItems += parseInt(input.value) || 0;
        });
        
        
        console.log(`Total items selected: ${totalItems}`);
        
    }


    const orderForm = document.querySelector('form'); 
    if (orderForm) {
        orderForm.addEventListener('submit', function(e) {
            let isValid = true;
            const requiredFields = orderForm.querySelectorAll('[required]');
            
            requiredFields.forEach(field => {
                if (!field.value.trim()) {
                    isValid = false;
                    field.style.borderColor = 'red';
                } else {
                    field.style.borderColor = 'blue';
                }
            });
            
            if (!isValid) {
                e.preventDefault();
                alert('Please fill in all required fields');
            }
        });
    }

    
    window.addEventListener('resize', function() {
        if (window.innerWidth > 768) {
            document.querySelector('.navigation').classList.remove('responsive');
        }
    });
});


function setupImageZoom() {
    const productImages = document.querySelectorAll('main img');
    productImages.forEach(img => {
        img.addEventListener('click', function() {
            
            const overlay = document.createElement('div');
            overlay.style.position = 'fixed';
            overlay.style.top = '0';
            overlay.style.left = '0';
            overlay.style.width = '100%';
            overlay.style.height = '100%';
            overlay.style.backgroundColor = 'rgba(0,0,0,0.8)';
            overlay.style.display = 'flex';
            overlay.style.justifyContent = 'center';
            overlay.style.alignItems = 'center';
            overlay.style.zIndex = '1000';
            overlay.style.cursor = 'zoom-out';
            
            const zoomedImg = document.createElement('img');
            zoomedImg.src = this.src;
            zoomedImg.style.maxHeight = '90%';
            zoomedImg.style.maxWidth = '90%';
    
            overlay.addEventListener('click', function() {
                document.body.removeChild(overlay);
            });
            
            overlay.appendChild(zoomedImg);
            document.body.appendChild(overlay);
        });
    });
}

window.onload = function() {
    setupImageZoom();
};